﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Office2010.Excel;


class Item //아이템 설정
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int Gold { get; set; }
    public int Attack { get; set; }
    public int Defense { get; set; }
    public int Health { get; set; }
    public string Description { get; set; }

    public Item(int id, string name, int gold, int attack, int defense, int health, string description)
    {
        Id = id;
        Name = name;
        Gold = gold;
        Attack = attack;
        Defense = defense;
        Health = health;
        Description = description;
    }
}

class ItemList //아이템 리스트 클래스
{
    public List<Item> itemList { get; set; }

    public Item this[int index]
    {
        get { return itemList[index]; }
        set { itemList[index] = value; }
    }
    public ItemList()
    {
        itemList = new List<Item>(); // 여기서 itemList를 초기화합니다.
    }

    public void GetItemList() //엑셀 파일로 아이템리스트 가져오기
    {

        string basePath = AppDomain.CurrentDomain.BaseDirectory;
        if (basePath == null) throw new InvalidOperationException("Base path cannot be null.");

        string filePath = Path.Combine(basePath, "Storage.xlsx");
        if (!File.Exists(filePath)) throw new FileNotFoundException($"File not found: {filePath}");

        var workbook = new XLWorkbook(filePath);
        if (workbook == null) throw new InvalidOperationException("Workbook cannot be null.");
        var worksheet = workbook.Worksheet(1); // 첫 번째 시트 사용
        var rows = worksheet.RangeUsed().RowsUsed(); // 사용된 행들

        foreach (var row in rows)
        {
            if (row.RowNumber() == 1) continue; // 첫 번째 행은 컬럼 이름이므로 건너뜁니다.

            int id = row.Cell(1).GetValue<int>();
            if (id > 0 && row.Cell(2).IsEmpty())
            {
                break; // 다른 값들은 없고 Id 값만 정의된 경우 루프 중단
            }

            string name = row.Cell(2).GetValue<string>();
            int gold = row.Cell(3).GetValue<int>();
            int attack = row.Cell(4).GetValue<int>();
            int defense = row.Cell(5).GetValue<int>();
            int health = row.Cell(6).GetValue<int>();
            string description = row.Cell(7).GetValue<string>();

            Item newItem = new Item(id, name, gold, attack, defense, health, description);

            itemList.Add(newItem);
        }
    }
} 

class Character //캐릭터 설정, 
{   
    public int Level { get; set; }
    public string Name { get; set; }
    public string Class { get; set; }
    public int Attack { get; set; }
    public int Defense { get; set; }
    public int Health { get; set; }
    public int Gold { get; set; }
    public List<Item> Inventory { get; set; }

    public Character(string name) //캐릭터 생성
    {
        Level = 1;
        Name = name;
        Class = "전사";
        Attack = 10;
        Defense = 5;
        Health = 100;
        Gold = 1500;
        Inventory = [];
} 

    public void DisplayStat() //상태창 선택
    {
        Console.Clear();
        Console.WriteLine($"Lv. {Level.ToString("D2")}");
        Console.WriteLine($"{Name} ( {Class} )");
        Console.WriteLine($"공격력 : {Attack}");
        Console.WriteLine($"방어력 : {Defense}");
        Console.WriteLine($"체력 : {Health}");
        Console.WriteLine($"Gold : {Gold} G");
        Console.WriteLine("\n원하시는 행동을 입력해주세요.");
        Console.WriteLine("0. 나가기");
        Console.Write(">> ");

        string input;
        
        //입력창
        do
        {
            input = Console.ReadLine();
            if (input == "0")
                return; // 메소드 종료 및 마을로 복귀
            else Console.WriteLine("잘못된 입력입니다. 다시 시도하세요.");
        }
        while (true);
    }

    public void DisplayInventory() //인벤토리 선택
    {
        Console.Clear();
        Console.WriteLine("인벤토리");
        Console.WriteLine("보유 중인 아이템을 관리할 수 있습니다.\n");

        Console.Write("[아이템 목록]\n");
        Console.WriteLine("1. 장착 관리");
        Console.WriteLine("0. 나가기\n");
        Console.WriteLine("원하시는 행동을 입력해주세요.");
        Console.Write(">> ");

        string input;

        do
        {
            input = Console.ReadLine();
            if (input == "0")
                return; // 메소드 종료 및 마을로 복귀
            else Console.WriteLine("잘못된 입력입니다. 다시 시도하세요.");
        }
        while (true);
    }

    public void DisplayShop_Main() //상점 메인화면
    {
        Console.Clear();
        Console.WriteLine("상점");
        Console.WriteLine("필요한 아이템을 얻을 수 있는 상점입니다..\n");
        Console.WriteLine("[보유 골드]");
        Console.WriteLine($"{Gold}G");

        //아이템 목록 > 인벤토리랑 비교해서 산거는 구매완료 상태로 바꿔야됨
        Console.WriteLine("[아이템 목록]");

        ItemList sales = Program.itemList;
        Dictionary<int, string> sellingItems = new Dictionary<int, string>();

        sellingItems[0] = string.Format($"{sales[0].Name}\t|\t방어력 +{sales[0].Defense}\t|\t{sales[0].Description}\t|\t");
        sellingItems[1] = string.Format($"{sales[1].Name}\t|\t방어력 +{sales[1].Defense}\t|\t{sales[1].Description}\t|\t");
        sellingItems[2] = string.Format($"{sales[2].Name}\t|\t방어력 +{sales[2].Defense}\t|\t{sales[2].Description}\t|\t");
        sellingItems[3] = string.Format($"{sales[3].Name}\t|\t방어력 +{sales[3].Defense}\t|\t{sales[3].Description}\t|\t");
        sellingItems[4] = string.Format($"{sales[4].Name}\t|\t방어력 +{sales[4].Defense}\t|\t{sales[4].Description}\t|\t");
        sellingItems[5] = string.Format($"{sales[5].Name}\t|\t방어력 +{sales[5].Defense}\t|\t{sales[5].Description}\t|\t");

        foreach  (KeyValuePair<int, string> sentence in sellingItems)
        {
            Console.WriteLine(UpdateSellString(sentence.Value, sentence.Key));
        }

        Console.WriteLine("\n1. 아이템 구매");
        Console.WriteLine("0. 나가기\n");
        Console.WriteLine("원하시는 행동을 입력해주세요.");
        Console.Write(">> ");

        string input;
        do
        {
            input = Console.ReadLine();
            if (input == "1")
            {
                DisplayShop_PurchaseUI();  // 구매 인터페이스 호출
                break;
            }
            else if (input == "0")
            {
                return; // 메소드 종료 및 마을로 복귀
            }
            else
            {
                Console.WriteLine("잘못된 입력입니다. 다시 시도하세요.");
            }
        }
        while (true);
    }

    string UpdateSellString(string sentence, int index) //함수: 상점이 판매할 아이템을 가졌는지 여부로 판매문장 업데이트
    {
        
        ItemList sales = Program.itemList;
        string tempSentence;

        bool isPurchased;
        if (Program.player.Inventory.Count == 0)
        {
            tempSentence = string.Format(sentence + $"{sales[index].Gold} G");
            return tempSentence;
        }

        isPurchased = Program.player.Inventory.Any(item => item.Id == index);
        if (isPurchased)
        {
            tempSentence = string.Format(sentence + "구매 완료");
        }
        else
        {
            tempSentence = string.Format(sentence + string.Format($"{sales[index].Gold} G"));
        }
        return tempSentence;

    } //판매할 아이템의 구매완료 or 골드 표시

    public void DisplayShop_PurchaseUI()
    {
        Console.Clear();
        Console.WriteLine("필요한 아이템을 얻을 수 있는 상점입니다.\n");
        Console.WriteLine("[보유 골드]");
        Console.WriteLine($"{Gold} G\n");

        Console.WriteLine("[아이템 목록]");
        Console.WriteLine("1. 수련자 갑옷    | 방어력 +5  | 수련에 도움을 주는 갑옷입니다.             |  1000 G");
        Console.WriteLine("2. 무쇠갑옷      | 방어력 +9  | 무쇠로 만들어져 튼튼한 갑옷입니다.           |  구매완료");
        Console.WriteLine("3. 스파르타의 갑옷 | 방어력 +15 | 스파르타의 전사들이 사용했다는 전설의 갑옷입니다.|  3500 G");
        Console.WriteLine("4. 낡은 검      | 공격력 +2  | 쉽게 볼 수 있는 낡은 검 입니다.            |  600 G");
        Console.WriteLine("5. 청동 도끼     | 공격력 +5  | 어디선가 사용됐던거 같은 도끼입니다.        |  1500 G");
        Console.WriteLine("6. 스파르타의 창  | 공격력 +7  | 스파르타의 전사들이 사용했다는 전설의 창입니다. |  구매완료");

        Console.WriteLine("\n0. 나가기");
        Console.WriteLine("원하시는 행동을 입력해주세요.");
        Console.Write(">> ");

        string input;
        do
        {
            input = Console.ReadLine();
            switch (input)
            {
                case "1":
                    // 아이템 구매 로직
                    break;
                case "2":
                    // 아이템 구매 로직
                    break;
                case "0":
                    return; // 구매 화면 종료 및 상점 메인 화면으로 복귀
                default:
                    Console.WriteLine("잘못된 입력입니다. 다시 시도하세요.");
                    break;
            }
        }
        while (true);

    }

}


class Program
{
    public static Character player = new Character("Chad"); //캐릭터 생성
    public static ItemList itemList = new ItemList(); //아이템 리스트
    
    static void Main(string[] args)
    {
        itemList.GetItemList();
        
        while (true)
        {
            Console.Clear();
            ShowTownMenu();
            
        }
    }

    static void ShowTownMenu() //마을 UI
    {
        Console.WriteLine("스파르타 마을에 오신 여러분 환영합니다.");
        Console.WriteLine("이곳에서 던전으로 들어가기 전 활동을 할 수 있습니다.\n");
        Console.WriteLine("1. 상태 보기");
        Console.WriteLine("2. 인벤토리");
        Console.WriteLine("3. 상점");
        Console.WriteLine("\n원하시는 행동을 입력해주세요.");
        Console.Write(">> ");

        string input = Console.ReadLine();
        HandleTownInput(input);
    }

    static void HandleTownInput(string input) //마을 입력창
    {
        switch (input)
        {
            case "1":
                player.DisplayStat();
                break;
            case "2":
                player.DisplayInventory();
                break;
            case "3":
                player.DisplayShop_Main();
                break;
            default:
                Console.WriteLine("잘못된 입력입니다. 다시 입력해주세요.");
                Console.ReadKey(); // 사용자가 아무 키나 누를 때까지 대기
                break;
        }
    }
}
